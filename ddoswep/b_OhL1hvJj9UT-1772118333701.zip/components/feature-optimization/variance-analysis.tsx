'use client'

import { Card } from '@/components/ui/card'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { vi } from '@/lib/vi'

interface Feature {
  name: string
  variance: number
  importance: number
}

interface Props {
  features: Feature[]
}

export function VarianceAnalysis({ features }: Props) {
  const varianceData = features.map(f => ({
    name: f.name.substring(0, 12),
    variance: f.variance,
    importance: f.importance * 100
  }))

  return (
    <div className="space-y-6">
      {/* Variance Chart */}
      <Card className="bg-card border-border p-6">
        <h3 className="text-lg font-bold mb-4">{vi.varianceAnalysis}</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={varianceData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
            <YAxis />
            <Tooltip formatter={(value) => `${value}%`} />
            <Legend />
            <Bar dataKey="variance" fill="hsl(var(--primary))" name="Phương sai (%)" />
          </BarChart>
        </ResponsiveContainer>
        <p className="text-sm text-muted-foreground mt-4">
          Các đặc trưng có phương sai cao mang thêm thông tin và giúp mô hình phân biệt các lớp tốt hơn.
        </p>
      </Card>

      {/* Low Variance Features */}
      <Card className="bg-yellow-500/5 border-yellow-500/20 p-6">
        <h4 className="text-lg font-bold mb-4">Cảnh báo: Đặc trưng Phương sai Thấp</h4>
        <div className="space-y-3">
          {features.filter(f => f.variance < 35).map((feature, idx) => (
            <div key={idx} className="flex justify-between items-center p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
              <span className="font-medium">{feature.name}</span>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Phương sai: {feature.variance}%</p>
                <p className="text-xs text-yellow-600 dark:text-yellow-400">Xem xét loại bỏ</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* High Variance Features */}
      <Card className="bg-green-500/5 border-green-500/20 p-6">
        <h4 className="text-lg font-bold mb-4">✓ Đặc trưng Phương sai Cao (Tốt)</h4>
        <div className="space-y-3">
          {features.filter(f => f.variance > 75).map((feature, idx) => (
            <div key={idx} className="flex justify-between items-center p-3 bg-green-500/10 rounded-lg border border-green-500/20">
              <span className="font-medium">{feature.name}</span>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Phương sai: {feature.variance}%</p>
                <p className="text-xs text-green-600 dark:text-green-400">Nên giữ lại</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
