'use client'

import { Card } from '@/components/ui/card'
import { vi } from '@/lib/vi'

const featureNames = [
  'Tần số Gói',
  'Kích thước',
  'Tỷ lệ Lỗi',
  'Thời gian',
  'Số cổng',
  'TTL'
]

// Mock correlation matrix
const correlations = [
  [1.00, 0.82, 0.65, 0.48, 0.32, 0.15],
  [0.82, 1.00, 0.71, 0.55, 0.38, 0.22],
  [0.65, 0.71, 1.00, 0.68, 0.45, 0.28],
  [0.48, 0.55, 0.68, 1.00, 0.52, 0.35],
  [0.32, 0.38, 0.45, 0.52, 1.00, 0.42],
  [0.15, 0.22, 0.28, 0.35, 0.42, 1.00]
]

function getColor(value: number): string {
  if (value > 0.8) return 'bg-red-500/40'
  if (value > 0.6) return 'bg-orange-500/40'
  if (value > 0.4) return 'bg-yellow-500/40'
  return 'bg-primary/20'
}

export function CorrelationMatrix() {
  return (
    <Card className="bg-card border-border p-6">
      <h3 className="text-lg font-bold mb-4">{vi.correlationMatrix}</h3>
      <div className="overflow-x-auto">
        <div className="inline-block min-w-full">
          <table className="text-xs">
            <thead>
              <tr>
                <th className="px-2 py-2 text-left"></th>
                {featureNames.map((name, idx) => (
                  <th key={idx} className="px-2 py-2 text-right text-muted-foreground max-w-12">
                    <div className="truncate">{name}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {correlations.map((row, i) => (
                <tr key={i}>
                  <td className="px-2 py-2 text-left text-muted-foreground font-semibold whitespace-nowrap">
                    {featureNames[i]}
                  </td>
                  {row.map((value, j) => (
                    <td
                      key={j}
                      className={`px-2 py-2 text-right font-mono rounded ${getColor(value)}`}
                    >
                      {value.toFixed(2)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="mt-6 space-y-2 text-sm text-foreground">
        <p className="font-semibold mb-3">Giải thích:</p>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-red-500/40"></div>
          <span>Tương quan Cao (0.8-1.0) - Có thể loại bỏ đặc trưng dư thừa</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-orange-500/40"></div>
          <span>Tương quan Trung bình (0.6-0.8)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-primary/20"></div>
          <span>Tương quan Thấp (0-0.6) - Đặc trưng độc lập, hữu ích</span>
        </div>
      </div>
    </Card>
  )
}
