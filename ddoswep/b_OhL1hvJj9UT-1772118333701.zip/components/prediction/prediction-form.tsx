'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

interface PredictionFormProps {
  onPredict: (data: Record<string, any>) => void
}

export function PredictionForm({ onPredict }: PredictionFormProps) {
  const [formData, setFormData] = useState({
    packetRate: '500',
    byteCount: '5000',
    protocol: 'TCP',
    sourcePort: '443',
    destinationPort: '80',
    duration: '60'
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onPredict(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="text-sm font-semibold block mb-2">Packet Rate (packets/sec)</label>
          <input
            type="number"
            name="packetRate"
            value={formData.packetRate}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-lg bg-input border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="0-10000"
            min="0"
            max="10000"
          />
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2">Byte Count (bytes)</label>
          <input
            type="number"
            name="byteCount"
            value={formData.byteCount}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-lg bg-input border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="0-50000"
            min="0"
          />
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2">Protocol Type</label>
          <select
            name="protocol"
            value={formData.protocol}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-lg bg-input border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option>TCP</option>
            <option>UDP</option>
            <option>ICMP</option>
            <option>Other</option>
          </select>
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2">Duration (seconds)</label>
          <input
            type="number"
            name="duration"
            value={formData.duration}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-lg bg-input border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="1-3600"
            min="1"
          />
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2">Source Port</label>
          <input
            type="number"
            name="sourcePort"
            value={formData.sourcePort}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-lg bg-input border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="1-65535"
            min="1"
            max="65535"
          />
        </div>

        <div>
          <label className="text-sm font-semibold block mb-2">Destination Port</label>
          <input
            type="number"
            name="destinationPort"
            value={formData.destinationPort}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-lg bg-input border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="1-65535"
            min="1"
            max="65535"
          />
        </div>
      </div>

      <Button
        type="submit"
        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-6"
      >
        Make Prediction
      </Button>
    </form>
  )
}
