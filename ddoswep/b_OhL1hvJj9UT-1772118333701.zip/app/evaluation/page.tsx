'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ChevronLeft, TrendingUp } from 'lucide-react'
import { ConfusionMatrix } from '@/components/evaluation/confusion-matrix'
import { MetricsCard } from '@/components/evaluation/metrics-card'
import { PerformanceChart } from '@/components/evaluation/performance-chart'
import { DetailedResults } from '@/components/evaluation/detailed-results'
import { vi } from '@/lib/vi'

export default function EvaluationPage() {
  // Mock evaluation data
  const metrics = {
    accuracy: 0.96,
    precision: 0.95,
    recall: 0.97,
    f1Score: 0.96,
    auc: 0.98,
    specificity: 0.94
  }

  const confusionMatrixData = {
    tn: 850,
    fp: 50,
    fn: 30,
    tp: 1070
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-4 h-16">
          <Link href="/training">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              {vi.back}
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">{vi.evaluationPageTitle}</h1>
            <p className="text-sm text-muted-foreground">{vi.evaluationPageStep}</p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <MetricsCard label={vi.accuracy} value={metrics.accuracy} />
          <MetricsCard label={vi.precision} value={metrics.precision} />
          <MetricsCard label={vi.recall} value={metrics.recall} />
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <MetricsCard label={vi.f1Score} value={metrics.f1Score} />
          <MetricsCard label={vi.aucRoc} value={metrics.auc} />
          <MetricsCard label={vi.specificity} value={metrics.specificity} />
        </div>

        {/* Confusion Matrix */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <Card className="bg-card border-border p-8">
            <h2 className="text-2xl font-bold mb-6">{vi.confusionMatrix}</h2>
            <ConfusionMatrix data={confusionMatrixData} />
          </Card>

          {/* Performance Chart */}
          <Card className="bg-card border-border p-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-primary" />
              {vi.performanceComparison}
            </h2>
            <PerformanceChart metrics={metrics} />
          </Card>
        </div>

        {/* Detailed Results */}
        <DetailedResults metrics={metrics} confusionMatrix={confusionMatrixData} />

        {/* Next Steps */}
        <Card className="bg-primary/5 border-primary/20 p-8">
          <h2 className="text-2xl font-bold mb-4">{vi.performanceSummary}</h2>
          <p className="text-muted-foreground mb-6">
            Mô hình của bạn đạt được {(metrics.accuracy * 100).toFixed(1)}% độ chính xác trên tập kiểm tra. Độ chính xác cao và độ nhạy cao cho thấy mô hình có thể phát hiện đáng tin cậy các tấn công DDoS trong khi giảm thiểu dương tính giả.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <Link href="/explainability">
              <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                {vi.exploreExplainability}
              </Button>
            </Link>
            <Link href="/experiments">
              <Button variant="outline" className="w-full">
                {vi.saveCompareExperiments}
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    </main>
  )
}
