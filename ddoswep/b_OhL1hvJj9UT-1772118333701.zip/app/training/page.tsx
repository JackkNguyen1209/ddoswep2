'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ChevronLeft, Play, Zap, X } from 'lucide-react'
import { AlgorithmSelector } from '@/components/training/algorithm-selector'
import { HyperparameterPanel } from '@/components/training/hyperparameter-panel'
import { AlgorithmComparison } from '@/components/training/algorithm-comparison'
import { vi } from '@/lib/vi'

const algorithms = [
  {
    id: 'ann',
    name: 'Artificial Neural Network',
    description: 'Deep learning model with multiple layers',
    icon: '🧠',
    hyperparams: {
      layers: { label: 'Hidden Layers', value: 3, min: 1, max: 5 },
      neurons: { label: 'Neurons per Layer', value: 128, min: 32, max: 512 },
      epochs: { label: 'Training Epochs', value: 100, min: 10, max: 500 },
      batchSize: { label: 'Batch Size', value: 32, min: 8, max: 128 }
    }
  },
  {
    id: 'svm',
    name: 'Support Vector Machine',
    description: 'High-dimensional classification algorithm',
    icon: '⚔️',
    hyperparams: {
      kernel: { label: 'Kernel Type', value: 'rbf', options: ['linear', 'rbf', 'poly'] },
      C: { label: 'Regularization (C)', value: 1, min: 0.1, max: 10 },
      gamma: { label: 'Kernel Coefficient', value: 'scale', options: ['scale', 'auto'] }
    }
  },
  {
    id: 'nb-gaussian',
    name: 'Gaussian Naive Bayes',
    description: 'Probabilistic classifier assuming normal distribution',
    icon: '📊',
    hyperparams: {
      priors: { label: 'Use Priors', value: true, type: 'boolean' }
    }
  },
  {
    id: 'nb-multinomial',
    name: 'Multinomial Naive Bayes',
    description: 'Fast and efficient for discrete features',
    icon: '📈',
    hyperparams: {
      alpha: { label: 'Smoothing (Alpha)', value: 1, min: 0, max: 2 }
    }
  },
  {
    id: 'nb-bernoulli',
    name: 'Bernoulli Naive Bayes',
    description: 'For binary feature vectors',
    icon: '🎲',
    hyperparams: {
      alpha: { label: 'Smoothing (Alpha)', value: 1, min: 0, max: 2 },
      fitPriors: { label: 'Fit Priors', value: true, type: 'boolean' }
    }
  },
  {
    id: 'logistic',
    name: 'Logistic Regression',
    description: 'Linear classification with probability estimates',
    icon: '📉',
    hyperparams: {
      C: { label: 'Inverse Regularization', value: 1, min: 0.1, max: 10 },
      solver: { label: 'Solver', value: 'lbfgs', options: ['lbfgs', 'liblinear', 'saga'] },
      maxIter: { label: 'Max Iterations', value: 100, min: 10, max: 500 }
    }
  },
  {
    id: 'knn',
    name: 'K-Nearest Neighbors',
    description: 'Distance-based instance-based learning',
    icon: '🎯',
    hyperparams: {
      k: { label: 'Number of Neighbors (K)', value: 5, min: 1, max: 20 },
      metric: { label: 'Distance Metric', value: 'euclidean', options: ['euclidean', 'manhattan'] },
      weights: { label: 'Weights', value: 'uniform', options: ['uniform', 'distance'] }
    }
  },
  {
    id: 'dt',
    name: 'Decision Tree',
    description: 'Tree-based model for interpretable decisions',
    icon: '🌳',
    hyperparams: {
      maxDepth: { label: 'Max Depth', value: 10, min: 1, max: 30 },
      minSamples: { label: 'Min Samples Split', value: 2, min: 2, max: 20 },
      criterion: { label: 'Split Criterion', value: 'gini', options: ['gini', 'entropy'] }
    }
  },
  {
    id: 'rf',
    name: 'Random Forest',
    description: 'Ensemble of decision trees for robust prediction',
    icon: '🌲',
    hyperparams: {
      nEstimators: { label: 'Number of Trees', value: 100, min: 10, max: 500 },
      maxDepth: { label: 'Max Depth', value: 15, min: 5, max: 50 },
      minSamples: { label: 'Min Samples Split', value: 2, min: 2, max: 20 }
    }
  },
  {
    id: 'xgb',
    name: 'Gradient Boosting',
    description: 'Advanced ensemble learning with sequential trees',
    icon: '🚀',
    hyperparams: {
      nEstimators: { label: 'Number of Boosters', value: 100, min: 10, max: 500 },
      learningRate: { label: 'Learning Rate', value: 0.1, min: 0.01, max: 1 },
      maxDepth: { label: 'Max Depth', value: 5, min: 3, max: 10 }
    }
  }
]

export default function TrainingPage() {
  const [selectedAlgorithms, setSelectedAlgorithms] = useState<string[]>([])
  const [training, setTraining] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [showComparison, setShowComparison] = useState(false)

  const toggleAlgorithm = (algoId: string) => {
    setSelectedAlgorithms(prev =>
      prev.includes(algoId)
        ? prev.filter(a => a !== algoId)
        : [...prev, algoId]
    )
  }

  const clearSelection = () => {
    setSelectedAlgorithms([])
  }

  const selectedAlgoObjects = algorithms.filter(a => selectedAlgorithms.includes(a.id))

  const handleStartTraining = async () => {
    setTraining(true)
    await new Promise(resolve => setTimeout(resolve, 3000))
    setTraining(false)
    setCompleted(true)
  }

  const handleProceed = () => {
    window.location.href = '/evaluation'
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-4 h-16">
          <Link href="/preprocessing">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              {vi.back}
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">{vi.trainingPageTitle}</h1>
            <p className="text-sm text-muted-foreground">{vi.trainingPageStep}</p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!showComparison ? (
          <div className="grid lg:grid-cols-4 gap-6">
            {/* Algorithm Selection - Main Content */}
            <div className="lg:col-span-3">
              <div className="mb-8">
                <h2 className="text-2xl font-bold mb-4">{vi.selectAlgorithm}</h2>
                <p className="text-muted-foreground mb-6">{vi.selectMultiple}</p>

                <div className="grid md:grid-cols-2 gap-4">
                  {algorithms.map(algo => (
                    <AlgorithmSelector
                      key={algo.id}
                      algorithm={algo}
                      selected={selectedAlgorithms.includes(algo.id)}
                      onSelect={() => toggleAlgorithm(algo.id)}
                    />
                  ))}
                </div>
              </div>

              {/* Comparison Preview */}
              {selectedAlgorithms.length > 0 && (
                <Card className="bg-primary/5 border-primary/30 p-6">
                  <h3 className="font-bold mb-4">{vi.selectedAlgorithms}</h3>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedAlgoObjects.map(algo => (
                      <div key={algo.id} className="bg-primary/20 border border-primary/40 rounded-full px-4 py-2 flex items-center gap-2">
                        <span>{algo.name}</span>
                        <button
                          onClick={() => toggleAlgorithm(algo.id)}
                          className="hover:text-destructive transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => setShowComparison(true)}
                      className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                    >
                      {vi.compareNow}
                    </Button>
                    <Button
                      onClick={clearSelection}
                      variant="outline"
                      className="flex-1"
                    >
                      {vi.clearSelection}
                    </Button>
                  </div>
                </Card>
              )}
            </div>

            {/* Fixed Hyperparameter Panel Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 space-y-4">
                {selectedAlgorithms.length > 0 ? (
                  <>
                    {selectedAlgorithms.length === 1 && (
                      <HyperparameterPanel algorithm={selectedAlgoObjects[0]} />
                    )}
                    {selectedAlgorithms.length > 1 && (
                      <Card className="bg-card/50 border-border p-6">
                        <h3 className="font-bold mb-3">{vi.selectedAlgorithms}</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          {selectedAlgorithms.length} {vi.selectAlgorithm.toLowerCase()} được chọn
                        </p>
                        <Button
                          onClick={() => setShowComparison(true)}
                          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                        >
                          {vi.compareNow}
                        </Button>
                      </Card>
                    )}

                    {/* Training Status */}
                    {completed && (
                      <Card className="bg-green-500/10 border-green-500/30 p-6">
                        <div className="text-center">
                          <Zap className="w-8 h-8 text-green-500 mx-auto mb-2" />
                          <h3 className="font-bold text-green-700 dark:text-green-300">{vi.trainingComplete}</h3>
                          <p className="text-xs text-green-600/80 dark:text-green-400/80 mt-2">{vi.trainingCompleteDesc}</p>
                        </div>
                        <Button
                          onClick={handleProceed}
                          className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground"
                        >
                          {vi.viewEvaluation}
                        </Button>
                      </Card>
                    )}

                    {!completed && (
                      <Button
                        onClick={handleStartTraining}
                        disabled={training}
                        size="lg"
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
                      >
                        <Play className="w-4 h-4" />
                        {training ? vi.trainingModel : vi.startTraining}
                      </Button>
                    )}
                  </>
                ) : (
                  <Card className="bg-card/50 border-border p-6 text-center">
                    <p className="text-muted-foreground text-sm">{vi.selectAlgorithms}</p>
                  </Card>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div>
            <Button
              onClick={() => setShowComparison(false)}
              variant="outline"
              className="mb-6 gap-2"
            >
              <ChevronLeft className="w-4 h-4" />
              {vi.back}
            </Button>
            <AlgorithmComparison algorithms={selectedAlgoObjects} />
          </div>
        )}
      </div>
    </main>
  )
}
