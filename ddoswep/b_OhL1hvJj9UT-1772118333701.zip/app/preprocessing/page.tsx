'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ChevronLeft, CheckCircle2, AlertCircle } from 'lucide-react'
import { PreprocessingStep } from '@/components/preprocessing/preprocessing-step'
import { vi } from '@/lib/vi'

interface ProcessingState {
  handleMissing: boolean
  encoding: boolean
  scaling: boolean
  balanced: boolean
  splitData: boolean
  completed: boolean
}

export default function PreprocessingPage() {
  const [processing, setProcessing] = useState<ProcessingState>({
    handleMissing: false,
    encoding: false,
    scaling: false,
    balanced: false,
    splitData: false,
    completed: false
  })

  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState<any>(null)

  useEffect(() => {
    // Load data from localStorage
    const savedData = localStorage.getItem('uploadedFile')
    if (savedData) {
      setData(JSON.parse(savedData))
    }
  }, [])

  const steps = [
    {
      title: 'Handle Missing Values',
      description: 'Remove or impute missing data points',
      icon: '📊'
    },
    {
      title: 'Encode Categorical Features',
      description: 'Convert categorical variables to numerical format',
      icon: '🔄'
    },
    {
      title: 'Feature Scaling',
      description: 'Normalize features to [0, 1] range using MinMaxScaler',
      icon: '📏'
    },
    {
      title: 'Handle Class Imbalance',
      description: 'Balance dataset using SMOTE or undersampling',
      icon: '⚖️'
    },
    {
      title: 'Train-Test Split',
      description: 'Split data into 80% training and 20% testing',
      icon: '✂️'
    }
  ]

  const runPreprocessing = async () => {
    setLoading(true)
    // Simulate processing steps
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800))
      setProcessing(prev => ({
        ...prev,
        [Object.keys(prev)[i]]: true
      }))
    }
    setProcessing(prev => ({ ...prev, completed: true }))
    setLoading(false)
  }

  const handleProceed = () => {
    window.location.href = '/training'
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-4 h-16">
          <Link href="/upload">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              {vi.back}
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">{vi.preprocessingTitle}</h1>
            <p className="text-sm text-muted-foreground">{vi.preprocessingStep}</p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card className="bg-card border-border p-8 mb-8">
          <h2 className="text-2xl font-bold mb-2">{vi.preprocessingDesc}</h2>
          <p className="text-muted-foreground mb-6">
            {vi.preprocessingDesc}
          </p>

          {data && (
            <div className="bg-card/50 border border-border rounded-lg p-4 mb-6">
              <p className="text-sm"><span className="text-primary font-semibold">Dataset loaded:</span> {data?.length} records ready for preprocessing</p>
            </div>
          )}

          {/* Warning */}
          <Card className="bg-amber-500/10 border-amber-500/30 p-4 mb-8 flex gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-amber-900 dark:text-amber-200">Cảnh báo Tiền xử lý</p>
              <p className="text-sm text-amber-800/80 dark:text-amber-300/80">Các hoạt động này không thể đảo ngược. Đảm bảo bạn có bản sao lưu của dữ liệu gốc.</p>
            </div>
          </Card>

          {/* Steps */}
          <div className="space-y-4 mb-8">
            {steps.map((s, idx) => (
              <PreprocessingStep
                key={idx}
                icon={s.icon}
                title={s.title}
                description={s.description}
                completed={Object.values(processing)[idx] as boolean}
                index={idx}
              />
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            {!processing.completed ? (
              <Button
                onClick={runPreprocessing}
                disabled={loading}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {loading ? vi.processingData : vi.startTraining}
              </Button>
            ) : (
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
                <span className="font-semibold">{vi.trainingComplete}</span>
              </div>
            )}
          </div>

          {processing.completed && (
            <div className="mt-8 p-6 bg-green-500/10 border border-green-500/30 rounded-lg">
              <h3 className="font-bold text-green-700 dark:text-green-300 mb-3">Sẵn sàng cho Huấn luyện</h3>
              <p className="text-sm text-green-600/80 dark:text-green-400/80 mb-4">
                Dữ liệu của bạn đã được tiền xử lý thành công và sẵn sàng để huấn luyện mô hình. Tập dữ liệu đã được chia thành huấn luyện (80%) và kiểm tra (20%).
              </p>
              <div className="flex gap-3">
                <Button
                  onClick={() => window.location.href = '/feature-optimization'}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Tiếp tục đến Tối ưu hóa Đặc trưng
                </Button>
                <Button
                  onClick={handleProceed}
                  variant="outline"
                >
                  Bỏ qua đến Huấn luyện
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </main>
  )
}
