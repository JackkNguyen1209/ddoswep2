'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { BarChart3, Brain, Zap, LineChart } from 'lucide-react'
import { vi } from '@/lib/vi'

const features = [
  {
    icon: BarChart3,
    title: vi.datasetManagement,
    description: vi.datasetDesc
  },
  {
    icon: Zap,
    title: vi.smartPreprocessing,
    description: vi.preprocessingDesc
  },
  {
    icon: Brain,
    title: vi.mlAlgorithms,
    description: vi.algorithmsDesc
  },
  {
    icon: LineChart,
    title: vi.modelEvaluation,
    description: vi.evaluationDesc
  }
]

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-primary" />
            <span className="text-xl font-bold">Phòng thí nghiệm Phát hiện DDoS</span>
          </div>
          <Link href="/upload">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {vi.getStarted}
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6">
              {vi.homeTitle} <span className="text-primary">ML Nâng cao</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {vi.homeDescription}
            </p>
            <div className="flex gap-4 flex-col sm:flex-row">
              <Link href="/upload">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto">
                  {vi.startBuilding}
                </Button>
              </Link>
              <Link href="/experiments">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  {vi.viewExperiments}
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Illustration area */}
          <div className="flex items-center justify-center">
            <div className="relative w-full h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-3xl"></div>
              <div className="relative bg-card border border-border rounded-2xl p-8 h-full flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4 w-full h-full">
                  <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 flex items-end justify-center">
                    <div className="flex gap-1">
                      <div className="w-2 h-12 bg-primary rounded-sm"></div>
                      <div className="w-2 h-16 bg-primary rounded-sm"></div>
                      <div className="w-2 h-14 bg-primary rounded-sm"></div>
                      <div className="w-2 h-20 bg-primary rounded-sm"></div>
                    </div>
                  </div>
                  <div className="bg-accent/10 border border-accent/20 rounded-lg p-4 flex items-center justify-center">
                    <div className="text-3xl text-accent">⚡</div>
                  </div>
                  <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 flex items-center justify-center">
                    <div className="w-full h-12 border border-primary/40 rounded relative">
                      <div className="absolute top-2 left-2 w-1 h-1 bg-primary rounded-full"></div>
                      <div className="absolute top-5 left-4 w-8 h-1 border-b border-primary/40"></div>
                    </div>
                  </div>
                  <div className="bg-accent/10 border border-accent/20 rounded-lg p-4 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-xl font-bold text-accent">98%</div>
                      <div className="text-xs text-muted-foreground">Accuracy</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-border">
        <div className="mb-12">
          <h2 className="text-4xl font-bold mb-4">Các Tính năng Mạnh mẽ</h2>
          <p className="text-muted-foreground text-lg max-w-2xl">
            Mọi thứ bạn cần để thành thạo học máy cho an toàn mạng
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feature, idx) => {
            const Icon = feature.icon
            return (
              <Card key={idx} className="bg-card/50 border-border p-6 hover:bg-card/80 transition-colors">
                <Icon className="w-12 h-12 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            )
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20 p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">{vi.readyExplore}</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            {vi.uploadDatasetDesc}
          </p>
          <Link href="/upload">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {vi.uploadDataset}
            </Button>
          </Link>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center text-muted-foreground">
            <p>Phòng thí nghiệm Phát hiện DDoS ML &copy; 2025. Xây dựng cho mục đích giáo dục.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
