'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { ChevronLeft, Zap, TrendingUp, BarChart3 } from 'lucide-react'
import { vi } from '@/lib/vi'
import { CorrelationMatrix } from '@/components/feature-optimization/correlation-matrix'
import { VarianceAnalysis } from '@/components/feature-optimization/variance-analysis'
import { OptimizationResults } from '@/components/feature-optimization/optimization-results'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const mockFeatures = [
  { name: 'Tần số Gói tin', variance: 92, importance: 0.95 },
  { name: 'Kích thước Gói tin', variance: 85, importance: 0.88 },
  { name: 'Tỷ lệ Lỗi', variance: 78, importance: 0.82 },
  { name: 'Thời gian Phản hồi', variance: 65, importance: 0.71 },
  { name: 'Số cổng Đích', variance: 45, importance: 0.52 },
  { name: 'TTL', variance: 32, importance: 0.38 },
  { name: 'Flags TCP', variance: 28, importance: 0.35 },
  { name: 'Payload Độ dài', variance: 15, importance: 0.18 },
  { name: 'Tổng Byte', variance: 88, importance: 0.85 },
  { name: 'Tỷ lệ Tái truyền', variance: 72, importance: 0.75 }
]

const accuracyData = [
  { features: 3, accuracy: 88.5, precision: 0.86, recall: 0.87 },
  { features: 4, accuracy: 91.2, precision: 0.89, recall: 0.90 },
  { features: 5, accuracy: 93.8, precision: 0.92, recall: 0.93 },
  { features: 6, accuracy: 94.5, precision: 0.93, recall: 0.94 },
  { features: 7, accuracy: 94.8, precision: 0.93, recall: 0.94 },
  { features: 8, accuracy: 95.1, precision: 0.94, recall: 0.95 },
  { features: 10, accuracy: 95.2, precision: 0.94, recall: 0.95 }
]

export default function FeatureOptimizationPage() {
  const [minFeatures, setMinFeatures] = useState(5)
  const [running, setRunning] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [selectedTab, setSelectedTab] = useState<'overview' | 'correlation' | 'variance' | 'results'>('overview')

  const handleOptimize = () => {
    setRunning(true)
    setTimeout(() => {
      setRunning(false)
      setCompleted(true)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-4 h-16">
          <Link href="/preprocessing">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              {vi.back}
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">{vi.featureSelectionPageTitle}</h1>
            <p className="text-sm text-muted-foreground">{vi.featureSelectionPageDesc}</p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar Controls */}
          <div className="lg:col-span-1">
            <Card className="bg-card border-border p-6 sticky top-24">
              <h3 className="font-bold mb-6">{vi.autoOptimize}</h3>

              <div className="space-y-6">
                {/* Min Features Slider */}
                <div>
                  <label className="text-sm font-semibold block mb-3">
                    {vi.selectMinFeatures}: <span className="text-primary">{minFeatures}</span>
                  </label>
                  <Slider
                    value={[minFeatures]}
                    onValueChange={(value) => setMinFeatures(value[0])}
                    min={2}
                    max={8}
                    step={1}
                    disabled={running}
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Chọn số lượng đặc trưng tối thiểu để tối ưu hóa
                  </p>
                </div>

                {/* Target Column */}
                <div>
                  <label className="text-sm font-semibold block mb-2">{vi.targetColumn}</label>
                  <select className="w-full px-3 py-2 rounded-lg bg-muted border border-border text-foreground text-sm">
                    <option>Label (phân loại)</option>
                    <option>Attack_Type</option>
                    <option>Severity</option>
                  </select>
                </div>

                {/* Optimize Button */}
                <Button
                  onClick={handleOptimize}
                  disabled={running}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
                >
                  <Zap className="w-4 h-4" />
                  {running ? vi.processingData : vi.runOptimization}
                </Button>

                {completed && (
                  <Card className="bg-green-500/10 border-green-500/30 p-4">
                    <p className="text-sm text-green-600 dark:text-green-400 font-semibold">
                      ✓ {vi.completedSuccessfully}
                    </p>
                  </Card>
                )}
              </div>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Tabs */}
            <div className="flex gap-2 mb-6 border-b border-border overflow-x-auto">
              {[
                { id: 'overview', label: 'Tổng quan' },
                { id: 'correlation', label: vi.featureCorrelation },
                { id: 'variance', label: vi.featureVariance },
                { id: 'results', label: vi.optimizationResults }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id as any)}
                  className={`px-4 py-3 border-b-2 transition-all text-sm font-medium whitespace-nowrap ${
                    selectedTab === tab.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Overview Tab */}
            {selectedTab === 'overview' && (
              <div className="space-y-6">
                {/* Feature Ranking */}
                <Card className="bg-card border-border p-6">
                  <h3 className="text-lg font-bold mb-4">{vi.featureRanking}</h3>
                  <div className="space-y-3">
                    {mockFeatures.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-4">
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                          {idx + 1}
                        </div>
                        <div className="flex-grow">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-medium">{feature.name}</span>
                            <span className="text-sm text-primary font-semibold">{(feature.importance * 100).toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div
                              className="bg-primary rounded-full h-2 transition-all"
                              style={{ width: `${feature.importance * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Accuracy Curve */}
                <Card className="bg-card border-border p-6">
                  <h3 className="text-lg font-bold mb-4">{vi.accuracyVsFeatures}</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={accuracyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="features" label={{ value: 'Số lượng Đặc trưng', position: 'insideBottomRight', offset: -5 }} />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                      <Line type="monotone" dataKey="accuracy" stroke="hsl(var(--primary))" name="Độ chính xác" strokeWidth={2} />
                      <Line type="monotone" dataKey="precision" stroke="hsl(var(--accent))" name="Độ chính xác" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </Card>

                {/* Recommendations */}
                <Card className="bg-primary/5 border-primary/20 p-6">
                  <h3 className="text-lg font-bold mb-4">Đề xuất</h3>
                  <div className="space-y-3 text-foreground">
                    <p className="text-sm">
                      Dựa trên phân tích, <span className="font-semibold">6 đặc trưng hàng đầu</span> cung cấp kết quả tối ưu với:
                    </p>
                    <ul className="space-y-2 ml-4 text-sm">
                      <li>✓ Độ chính xác: <span className="font-bold text-primary">94.5%</span></li>
                      <li>✓ Precision: <span className="font-bold text-primary">0.93</span></li>
                      <li>✓ Recall: <span className="font-bold text-primary">0.94</span></li>
                      <li>✓ Thời gian huấn luyện: <span className="font-bold text-primary">nhanh hơn 30%</span></li>
                    </ul>
                  </div>
                </Card>
              </div>
            )}

            {selectedTab === 'correlation' && <CorrelationMatrix />}
            {selectedTab === 'variance' && <VarianceAnalysis features={mockFeatures} />}
            {selectedTab === 'results' && <OptimizationResults />}
          </div>
        </div>
      </div>
    </div>
  )
}
