'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ChevronLeft, Upload, AlertCircle, CheckCircle2 } from 'lucide-react'
import { PredictionForm } from '@/components/prediction/prediction-form'
import { PredictionResult } from '@/components/prediction/prediction-result'

export default function PredictionPage() {
  const [prediction, setPrediction] = useState<{
    result: string
    confidence: number
    probability: number
  } | null>(null)

  const handlePredict = (data: Record<string, any>) => {
    // Simulate prediction
    const mockConfidence = Math.random() * 0.2 + 0.85
    const isAttack = Math.random() > 0.5
    
    setPrediction({
      result: isAttack ? 'DDoS Attack' : 'Normal Traffic',
      confidence: mockConfidence,
      probability: isAttack ? mockConfidence : 1 - mockConfidence
    })
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-4 h-16">
          <Link href="/feature-selection">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">Make Predictions</h1>
            <p className="text-sm text-muted-foreground">Test your trained model</p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card className="bg-card border-border p-8 mb-6">
              <h2 className="text-2xl font-bold mb-2">Enter Network Traffic Data</h2>
              <p className="text-muted-foreground mb-6">
                Provide network metrics to get a DDoS detection prediction
              </p>
              <PredictionForm onPredict={handlePredict} />
            </Card>

            {prediction && (
              <Card className="bg-card border-border p-8">
                <h3 className="text-xl font-bold mb-4">Prediction Result</h3>
                <PredictionResult prediction={prediction} />
              </Card>
            )}
          </div>

          {/* Sidebar Info */}
          <div className="space-y-4">
            <Card className="bg-primary/10 border-primary/20 p-6">
              <h3 className="font-bold text-primary mb-3">Example Values</h3>
              <div className="space-y-2 text-sm">
                <div className="text-muted-foreground">
                  <span className="font-semibold">Packet Rate:</span> 100-10000 packets/sec
                </div>
                <div className="text-muted-foreground">
                  <span className="font-semibold">Byte Count:</span> 100-50000 bytes
                </div>
                <div className="text-muted-foreground">
                  <span className="font-semibold">Duration:</span> 1-3600 seconds
                </div>
              </div>
            </Card>

            <Card className="bg-card/50 border-border p-6">
              <h3 className="font-bold mb-3 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                Best Practices
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex gap-2">
                  <span>•</span>
                  <span>Ensure input features match training data scale</span>
                </li>
                <li className="flex gap-2">
                  <span>•</span>
                  <span>Verify data quality before prediction</span>
                </li>
                <li className="flex gap-2">
                  <span>•</span>
                  <span>Monitor confidence scores for reliability</span>
                </li>
              </ul>
            </Card>

            <Link href="/experiments">
              <Button variant="outline" className="w-full">
                View All Experiments
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
