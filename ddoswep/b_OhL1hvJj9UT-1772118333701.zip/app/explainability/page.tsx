'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ChevronLeft, Lightbulb, BookOpen } from 'lucide-react'
import { FeatureImportance } from '@/components/explainability/feature-importance'
import { AlgorithmExplanation } from '@/components/explainability/algorithm-explanation'

const algorithmExplanations: Record<string, {
  principle: string
  howItWorks: string[]
  advantages: string[]
  disadvantages: string[]
  bestFor: string
}> = {
  ann: {
    principle: 'Multi-layer perceptron using backpropagation',
    howItWorks: [
      'Multiple layers of interconnected neurons',
      'Forward pass: data flows through layers',
      'Backpropagation: gradients computed backwards',
      'Weights updated to minimize loss'
    ],
    advantages: [
      'Can learn complex non-linear relationships',
      'Excellent for high-dimensional data',
      'Flexible architecture for custom problems'
    ],
    disadvantages: [
      'Prone to overfitting',
      'Requires large datasets',
      'Computationally expensive'
    ],
    bestFor: 'Complex pattern recognition, DDoS behavior modeling'
  },
  svm: {
    principle: 'Find optimal hyperplane that maximizes class separation',
    howItWorks: [
      'Maps data to higher-dimensional space',
      'Finds maximum-margin hyperplane',
      'Uses support vectors for decision boundary',
      'Kernel trick enables non-linear separation'
    ],
    advantages: [
      'Effective in high dimensions',
      'Memory efficient',
      'Works well with clear separation'
    ],
    disadvantages: [
      'Slow with large datasets',
      'Requires feature scaling',
      'Hard to interpret predictions'
    ],
    bestFor: 'Binary classification with high-dimensional features'
  },
  'nb-gaussian': {
    principle: 'Apply Bayes theorem with normal distribution assumption',
    howItWorks: [
      'Calculates probability of each class',
      'Uses Bayes theorem: P(Class|Features)',
      'Assumes features are independent',
      'Assumes Gaussian (normal) distribution'
    ],
    advantages: [
      'Fast and simple',
      'Works well with small datasets',
      'Good baseline model'
    ],
    disadvantages: [
      'Independence assumption rarely true',
      'Assumes normal distribution',
      'Can be outperformed by complex models'
    ],
    bestFor: 'Quick baseline, text classification'
  },
  'logistic': {
    principle: 'Linear classifier using logistic function',
    howItWorks: [
      'Models probability using logistic sigmoid',
      'Finds optimal weights using gradient descent',
      'Produces probability scores 0-1',
      'Threshold determines classification'
    ],
    advantages: [
      'Fast and interpretable',
      'Probabilistic outputs',
      'Good for linear relationships'
    ],
    disadvantages: [
      'Limited to linear relationships',
      'Assumes linear decision boundary',
      'Sensitive to outliers'
    ],
    bestFor: 'Interpretable baseline, probabilistic predictions'
  },
  'knn': {
    principle: 'Classify based on nearest neighbors',
    howItWorks: [
      'Store all training data',
      'For new sample, find K nearest neighbors',
      'Use majority vote for classification',
      'Distance metric determines "closeness"'
    ],
    advantages: [
      'Simple and intuitive',
      'No training phase',
      'Adapts to local patterns'
    ],
    disadvantages: [
      'Slow prediction time',
      'Sensitive to K value',
      'Poor with high-dimensional data'
    ],
    bestFor: 'Non-linear patterns, local anomaly detection'
  },
  'dt': {
    principle: 'Recursively partition feature space',
    howItWorks: [
      'Select best split at each node',
      'Recursive partitioning of data',
      'Creates decision tree structure',
      'Leaf nodes represent predictions'
    ],
    advantages: [
      'Highly interpretable',
      'No feature scaling needed',
      'Handles mixed feature types'
    ],
    disadvantages: [
      'Prone to overfitting',
      'Biased to dominant classes',
      'Unstable with small data changes'
    ],
    bestFor: 'Interpretable models, rule extraction'
  },
  'rf': {
    principle: 'Ensemble of decision trees with bootstrap aggregating',
    howItWorks: [
      'Create multiple decision trees',
      'Each tree trained on random subset',
      'Combine predictions by voting',
      'Reduce variance through ensemble'
    ],
    advantages: [
      'Reduces overfitting',
      'Handles mixed features',
      'Feature importance built-in'
    ],
    disadvantages: [
      'Less interpretable than single tree',
      'Slower prediction',
      'Many hyperparameters'
    ],
    bestFor: 'Production systems, balanced performance'
  }
}

export default function ExplainabilityPage() {
  const features = [
    { name: 'Packet Rate', importance: 0.28, type: 'network' },
    { name: 'Byte Count', importance: 0.22, type: 'network' },
    { name: 'Protocol Type', importance: 0.18, type: 'network' },
    { name: 'Source Port', importance: 0.15, type: 'network' },
    { name: 'Destination Port', importance: 0.12, type: 'network' },
    { name: 'Duration', importance: 0.05, type: 'temporal' }
  ]

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-4 h-16">
          <Link href="/evaluation">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold">Model Explainability</h1>
            <p className="text-sm text-muted-foreground">Understand model decisions</p>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Feature Importance */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <Lightbulb className="w-8 h-8 text-primary" />
            Feature Importance Analysis
          </h2>
          <p className="text-muted-foreground mb-6">
            Which features have the most impact on model predictions for DDoS detection
          </p>
          <FeatureImportance features={features} />
        </div>

        {/* Algorithm Explanation */}
        <div>
          <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-primary" />
            Algorithm Principles
          </h2>
          <p className="text-muted-foreground mb-6">
            Deep dive into how each algorithm works for DDoS detection
          </p>
          
          <div className="grid md:grid-cols-2 gap-6">
            {Object.entries(algorithmExplanations).map(([algo, explanation]) => (
              <AlgorithmExplanation
                key={algo}
                algorithm={algo.toUpperCase()}
                explanation={explanation}
              />
            ))}
          </div>
        </div>

        {/* Next Steps */}
        <Card className="bg-primary/5 border-primary/20 p-8 mt-12">
          <h2 className="text-2xl font-bold mb-4">Continue Your ML Journey</h2>
          <p className="text-muted-foreground mb-6">
            Now that you understand your model, explore feature selection and make predictions on new data.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <Link href="/feature-selection">
              <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                Feature Selection & Optimization
              </Button>
            </Link>
            <Link href="/prediction">
              <Button variant="outline" className="w-full">
                Make Predictions
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    </main>
  )
}
