'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ChevronLeft, Plus, Trash2, Star } from 'lucide-react'

interface Experiment {
  id: string
  name: string
  algorithm: string
  accuracy: number
  f1Score: number
  trainingTime: number
  date: string
  featured?: boolean
}

export default function ExperimentsPage() {
  const experiments: Experiment[] = [
    {
      id: '1',
      name: 'Random Forest v3',
      algorithm: 'Random Forest',
      accuracy: 0.96,
      f1Score: 0.958,
      trainingTime: 145,
      date: '2025-02-26',
      featured: true
    },
    {
      id: '2',
      name: 'Neural Network v2',
      algorithm: 'Artificial Neural Network',
      accuracy: 0.955,
      f1Score: 0.952,
      trainingTime: 280,
      date: '2025-02-25'
    },
    {
      id: '3',
      name: 'SVM Baseline',
      algorithm: 'Support Vector Machine',
      accuracy: 0.94,
      f1Score: 0.935,
      trainingTime: 95,
      date: '2025-02-24'
    },
    {
      id: '4',
      name: 'Logistic Regression',
      algorithm: 'Logistic Regression',
      accuracy: 0.92,
      f1Score: 0.915,
      trainingTime: 35,
      date: '2025-02-23'
    },
    {
      id: '5',
      name: 'Gradient Boosting v1',
      algorithm: 'Gradient Boosting',
      accuracy: 0.965,
      f1Score: 0.962,
      trainingTime: 200,
      date: '2025-02-22'
    }
  ]

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ChevronLeft className="w-4 h-4" />
                Home
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold">Experiment History</h1>
              <p className="text-sm text-muted-foreground">Manage and compare model experiments</p>
            </div>
          </div>
          <Link href="/training">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
              <Plus className="w-4 h-4" />
              New Experiment
            </Button>
          </Link>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Summary Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="bg-card border-border p-6">
            <p className="text-sm text-muted-foreground mb-2">Total Experiments</p>
            <p className="text-3xl font-bold">{experiments.length}</p>
          </Card>
          <Card className="bg-card border-border p-6">
            <p className="text-sm text-muted-foreground mb-2">Best Accuracy</p>
            <p className="text-3xl font-bold text-primary">
              {(Math.max(...experiments.map(e => e.accuracy)) * 100).toFixed(2)}%
            </p>
          </Card>
          <Card className="bg-card border-border p-6">
            <p className="text-sm text-muted-foreground mb-2">Avg F1 Score</p>
            <p className="text-3xl font-bold text-accent">
              {(experiments.reduce((a, b) => a + b.f1Score, 0) / experiments.length * 100).toFixed(2)}%
            </p>
          </Card>
          <Card className="bg-card border-border p-6">
            <p className="text-sm text-muted-foreground mb-2">Fastest Training</p>
            <p className="text-3xl font-bold text-foreground">
              {Math.min(...experiments.map(e => e.trainingTime))}s
            </p>
          </Card>
        </div>

        {/* Experiments Table */}
        <Card className="bg-card border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-card/50 border-b border-border">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold text-primary">Experiment</th>
                  <th className="px-6 py-4 text-left font-semibold text-primary">Algorithm</th>
                  <th className="px-6 py-4 text-left font-semibold text-primary">Accuracy</th>
                  <th className="px-6 py-4 text-left font-semibold text-primary">F1 Score</th>
                  <th className="px-6 py-4 text-left font-semibold text-primary">Training Time</th>
                  <th className="px-6 py-4 text-left font-semibold text-primary">Date</th>
                  <th className="px-6 py-4 text-left font-semibold text-primary">Actions</th>
                </tr>
              </thead>
              <tbody>
                {experiments.map((exp, idx) => (
                  <tr key={exp.id} className={`border-b border-border/50 hover:bg-primary/5 transition-colors ${
                    idx === 0 ? 'bg-primary/5' : ''
                  }`}>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {exp.featured && <Star className="w-4 h-4 text-amber-500 fill-amber-500" />}
                        <span className="font-semibold">{exp.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">{exp.algorithm}</td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="font-bold text-primary">
                        {(exp.accuracy * 100).toFixed(2)}%
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="font-bold text-accent">
                        {(exp.f1Score * 100).toFixed(2)}%
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">{exp.trainingTime}s</td>
                    <td className="px-6 py-4 text-muted-foreground">{exp.date}</td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 hover:text-primary"
                          title="Delete experiment"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Best Model Card */}
        <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20 p-12 mt-12 text-center">
          <Badge className="bg-primary text-primary-foreground mb-4">Top Performer</Badge>
          <h2 className="text-3xl font-bold mb-2">Gradient Boosting v1</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Achieved 96.5% accuracy with excellent F1 score of 0.962. Recommended for production deployment.
          </p>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
            Deploy This Model
          </Button>
        </Card>
      </div>
    </main>
  )
}
